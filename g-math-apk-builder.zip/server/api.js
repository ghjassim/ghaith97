// server/api.js

const express = require('express');
const { randomUUID } = require('crypto'); // لتوليد معرفات فريدة (UUIDs)
const router = express.Router();

/**
 * @typedef {object} EquationHistoryItem
 * @property {string} id - Unique identifier for the saved equation.
 * @property {string} rawInput - The original equation string entered by the user.
 * @property {object} parsedEquation - Structured representation of the equation for backend processing.
 * @property {string} solution - The calculated solution, formatted for display.
 * @property {string} createdAt - Timestamp of when the equation was solved and saved (ISO 8601).
 */

/**
 * @typedef {object} EquationType
 * @property {string} id - Unique identifier for the equation type.
 * @property {string} name - The name of the equation type (e.g., "Linear Equation").
 * @property {string} description - A description of the equation type.
 */

// -----------------------------------------------------------
// بيانات وهمية في الذاكرة (In-memory Mock Data)
// هذه البيانات ستحاكي قاعدة بياناتك
// -----------------------------------------------------------

/** @type {EquationHistoryItem[]} */
const equationHistory = [
  {
    id: 'eq-h-1',
    rawInput: '2 + 3 * (4 - 1)',
    parsedEquation: { type: 'arithmetic', expression: '2 + 3 * (4 - 1)' },
    solution: '11',
    createdAt: new Date('2023-01-15T10:00:00Z').toISOString(),
  },
  {
    id: 'eq-h-2',
    rawInput: 'x^2 - 4 = 0',
    parsedEquation: { type: 'quadratic', expression: 'x^2 - 4 = 0' },
    solution: 'x = 2, x = -2',
    createdAt: new Date('2023-01-15T10:05:30Z').toISOString(),
  },
  {
    id: 'eq-h-3',
    rawInput: 'sin(pi/2)',
    parsedEquation: { type: 'trigonometric', expression: 'sin(pi/2)' },
    solution: '1',
    createdAt: new Date('2023-01-15T10:10:15Z').toISOString(),
  },
];

/** @type {EquationType[]} */
const equationTypes = [
  {
    id: 'eq-type-1',
    name: 'Arithmetic',
    description: 'Basic mathematical operations like addition, subtraction, multiplication, division.',
  },
  {
    id: 'eq-type-2',
    name: 'Algebraic',
    description: 'Equations involving variables, powers, and roots.',
  },
  {
    id: 'eq-type-3',
    name: 'Trigonometric',
    description: 'Equations involving trigonometric functions like sin, cos, tan.',
  },
];

// -----------------------------------------------------------
// معالجات نقاط النهاية (API Endpoints Handlers)
// -----------------------------------------------------------

/**
 * @route POST /api/solve-equation
 * @desc Sends a mathematical equation to the backend for processing and solving, returning the solution.
 * @body {string} rawInput - The equation string.
 * @returns {EquationHistoryItem} The solved equation item.
 */
router.post('/solve-equation', (req, res) => {
  const { rawInput } = req.body;

  if (!rawInput) {
    return res.status(400).json({ message: 'rawInput is required in the request body.' });
  }

  // محاكاة عملية المعالجة والحل
  // في تطبيق حقيقي، سيتم هنا استدعاء محرك حل المعادلات
  const newEquation = {
    id: randomUUID(),
    rawInput: rawInput,
    parsedEquation: { /* محاكاة: هيكل معادلة تم تحليلها */ type: 'unknown', expression: rawInput },
    solution: `Solution for "${rawInput}" (mocked)`, // حل وهمي
    createdAt: new Date().toISOString(),
  };

  equationHistory.push(newEquation);
  res.status(201).json(newEquation); // 201 Created
});

/**
 * @route GET /api/history
 * @desc Retrieves a list of previously solved equations stored in the user's history.
 * @returns {EquationHistoryItem[]} An array of solved equation items.
 */
router.get('/history', (req, res) => {
  res.status(200).json(equationHistory);
});

/**
 * @route GET /api/equation/:id
 * @desc Retrieves the detailed information for a specific solved equation by its ID.
 * @param {string} id - The ID of the equation to retrieve.
 * @returns {EquationHistoryItem} The specific equation item.
 */
router.get('/equation/:id', (req, res) => {
  const { id } = req.params;
  const equation = equationHistory.find(eq => eq.id === id);

  if (equation) {
    res.status(200).json(equation);
  } else {
    res.status(404).json({ message: 'Equation not found.' });
  }
});

/**
 * @route DELETE /api/equation/:id
 * @desc Deletes a specific solved equation from the user's history.
 * @param {string} id - The ID of the equation to delete.
 * @returns {void}
 */
router.delete('/equation/:id', (req, res) => {
  const { id } = req.params;
  const initialLength = equationHistory.length;
  equationHistory.splice(equationHistory.findIndex(eq => eq.id === id), 1);

  if (equationHistory.length < initialLength) {
    res.status(204).end(); // 204 No Content
  } else {
    res.status(404).json({ message: 'Equation not found.' });
  }
});

// -----------------------------------------------------------
// نقاط نهاية الإدارة (Admin Endpoints)
// -----------------------------------------------------------

/**
 * @route GET /api/admin/equation-types
 * @desc Retrieves a list of supported equation types for management in the admin panel.
 * @returns {EquationType[]} An array of supported equation types.
 */
router.get('/admin/equation-types', (req, res) => {
  res.status(200).json(equationTypes);
});

/**
 * @route POST /api/admin/equation-types
 * @desc Adds a new equation type to the system via the admin panel.
 * @body {string} name - The name of the new equation type.
 * @body {string} description - A description of the new equation type.
 * @returns {EquationType} The newly added equation type.
 */
router.post('/admin/equation-types', (req, res) => {
  const { name, description } = req.body;

  if (!name || !description) {
    return res.status(400).json({ message: 'Name and description are required for a new equation type.' });
  }

  const newType = {
    id: randomUUID(),
    name,
    description,
  };

  equationTypes.push(newType);
  res.status(201).json(newType); // 201 Created
});

/**
 * @route PUT /api/admin/equation-types/:id
 * @desc Updates an existing equation type via the admin panel.
 * @param {string} id - The ID of the equation type to update.
 * @body {string} name - The new name for the equation type (optional).
 * @body {string} description - The new description for the equation type (optional).
 * @returns {EquationType} The updated equation type.
 */
router.put('/admin/equation-types/:id', (req, res) => {
  const { id } = req.params;
  const { name, description } = req.body;

  const typeIndex = equationTypes.findIndex(type => type.id === id);

  if (typeIndex !== -1) {
    const updatedType = {
      ...equationTypes[typeIndex],
      name: name || equationTypes[typeIndex].name,
      description: description || equationTypes[typeIndex].description,
    };
    equationTypes[typeIndex] = updatedType;
    res.status(200).json(updatedType);
  } else {
    res.status(404).json({ message: 'Equation type not found.' });
  }
});

module.exports = router;