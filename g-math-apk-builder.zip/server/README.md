# Backend

Generated stub for math-equation-solver. Run with `node server/index.js` after wiring an Express server.