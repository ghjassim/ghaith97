import React from 'react';

export default function About() {
  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        <h1
          className="text-4xl font-bold text-center mb-8"
          style={{ color: '#4A90E2' }}
        >
          About Our Application
        </h1>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Mission</h2>
          <p className="text-gray-700 leading-relaxed">
            Our application empowers users to solve complex mathematical problems with ease,
            combining elegant design, robust functionality, and a seamless user experience.
            We strive to bridge the gap between theoretical rigor and practical usability.
          </p>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-medium mb-2">Alice Johnson</h3>
              <p className="text-gray-600">Lead Developer • React & TypeScript Enthusiast</p>
            </div>
            <div>
              <h3 className="font-medium mb-2">Ben Li</h3>
              <p className="text-gray-600">UI/UX Designer • Minimalist Aesthetics</p>
            </div>
            <div>
              <h3 className="font-medium mb-2">Chloe Kim</h3>
              <p className="text-gray-600">Product Manager • Precision & Clarity</p>
            </div>
            <div>
              <h3 className="font-medium mb-2">Daniel Ortiz</h3>
              <p className="text-gray-600">Backend Engineer • Scalability Expert</p>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Technology Stack</h2>
          <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <li className="p-4 bg-white rounded-lg shadow">
              <h3 className="font-medium mb-2">React (v18)</h3>
              <p className="text-gray-600">Declarative UI for dynamic interfaces.</p>
            </li>
            <li className="p-4 bg-white rounded-lg shadow">
              <h3 className="font-medium mb-2">Tailwind CSS</h3>
              <p className="text-gray-600">Utility-first styling for rapid development.</p>
            </li>
            <li className="p-4 bg-white rounded-lg shadow">
              <h3 className="font-medium mb-2">Vite</h3>
              <p className="text-gray-600">Fast bundling and dev server.</p>
            </li>
            <li className="p-4 bg-white rounded-lg shadow">
              <h3 className="font-medium mb-2">TypeScript</h3>
              <p className="text-gray-600">Strong typing for reliability.</p>
            </li>
            <li className="p-4 bg-white rounded-lg shadow">
              <h3 className="font-medium mb-2">Node.js & Express</h3>
              <p className="text-gray-600">Server-side API and data handling.</p>
            </li>
            <li className="p-4 bg-white rounded-lg shadow">
              <h3 className="font-medium mb-2">PostgreSQL</h3>
              <p className="text-gray-600">Structured data storage.</p>
            </li>
          </ul>
        </section>

        <footer className="pt-12 border-t border-gray-200 text-center text-gray-500">
          © 2026 MathSolve – All rights reserved.
        </footer>
      </div>
    </div>
  );
}