import React, { useState } from 'react';

export default function SettingsPage() {
  const [isDarkMode, setDarkMode] = useState(false);
  const [fontSize, setFontSize] = useState('base');

  const toggleDarkMode = () => setDarkMode(prev => !prev);
  const handleFontSizeChange = (e) => setFontSize(e.target.value);

  return (
    <div className={`${isDarkMode ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-900'} min-h-screen flex flex-col items-center py-8`}>
      <header className="w-full max-w-3xl mb-8">
        <h1 className="text-3xl font-semibold text-center" style={{ color: '#4A90E2' }}>
          Settings
        </h1>
      </header>

      <section className="w-full max-w-3xl bg-white shadow-md rounded-lg p-6 space-y-6">
        {/* Theme Section */}
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-medium">Appearance</h2>
          <button
            onClick={toggleDarkMode}
            className={`flex items-center space-x-2 p-2 rounded-full transition-colors duration-200 ${
              isDarkMode ? 'bg-[#4A90E2] text-white' : 'bg-gray-200 text-gray-800'
            }`}
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              viewBox="0 0 24 24"
            >
              {isDarkMode ? (
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707M18.364 17.657l-.707-.707M6.343 6.343l-.707-.707"
                />
              ) : (
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 5a7 7 0 100 14 7 7 0 000-14z"
                />
              )}
            </svg>
            <span className="text-sm">{isDarkMode ? 'Dark' : 'Light'}</span>
          </button>
        </div>

        {/* Display Preferences Section */}
        <div>
          <h3 className="text-lg font-medium mb-2">Font Size</h3>
          <select
            value={fontSize}
            onChange={handleFontSizeChange}
            className="bg-gray-50 border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-[#4A90E2] focus:border-[#4A90E2]"
          >
            <option value="sm">Small</option>
            <option value="base">Medium</option>
            <option value="lg">Large</option>
            <option value="xl">Extra Large</option>
          </select>
        </div>

        {/* Sample Preview */}
        <div className="p-4 rounded-md bg-gray-100">
          <h4 className="text-base font-medium mb-1" style={{ color: '#4A90E2' }}>
            Preview
          </h4>
          <p className={`text-${fontSize} leading-relaxed`}>
            This is a sample text to show the current font size and theme settings. Adjust the
            options above to see the changes in real-time. This layout reflects the modern,
            minimalist design principles of the application.
          </p>
        </div>
      </section>
    </div>
  );
}