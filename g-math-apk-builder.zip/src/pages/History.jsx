import React from 'react';

export default function HistoryPage() {
  const solvedEquations = [
    {
      id: 'eq1',
      equation: '∫(x^2 + 2x) dx',
      result: 'x^3/3 + x^2 + C',
      timestamp: '2023-10-26T10:30:00Z',
      type: 'حساب التفاضل والتكامل',
    },
    {
      id: 'eq2',
      equation: '2x + 5 = 15',
      result: 'x = 5',
      timestamp: '2023-10-26T09:45:00Z',
      type: 'جبر',
    },
    {
      id: 'eq3',
      equation: 'E = mc^2',
      result: 'تكافؤ الكتلة والطاقة',
      timestamp: '2023-10-25T17:00:00Z',
      type: 'فيزياء',
    },
    {
      id: 'eq4',
      equation: 'sin(pi/2)',
      result: '1',
      timestamp: '2023-10-25T14:10:00Z',
      type: 'حساب المثلثات',
    },
    {
      id: 'eq5',
      equation: 'log_2(8)',
      result: '3',
      timestamp: '2023-10-24T11:20:00Z',
      type: 'لوغاريتمات',
    },
    {
      id: 'eq6',
      equation: 'd/dx (e^x * sin(x))',
      result: 'e^x * (sin(x) + cos(x))',
      timestamp: '2023-10-23T16:05:00Z',
      type: 'حساب التفاضل والتكامل',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 p-4 sm:p-6 md:p-8 font-sans antialiased flex flex-col items-center">
      {/* Header Section */}
      <header className="mb-10 text-center max-w-2xl w-full">
        <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-[#4A90E2] leading-tight">
          سجل المعادلات
        </h1>
        <p className="mt-3 text-lg sm:text-xl text-gray-600 dark:text-gray-400">
          استعرض المعادلات التي قمت بحلها مسبقاً وأعد الوصول إليها بكل سهولة ودقة.
        </p>
      </header>

      {/* Main Content Area */}
      <main className="max-w-5xl w-full">
        {solvedEquations.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {solvedEquations.map((equation) => (
              <div
                key={equation.id}
                className="bg-white dark:bg-gray-800 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 p-6 border border-gray-100 dark:border-gray-700 flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-center mb-4 text-sm font-medium">
                    <span className="bg-blue-50 dark:bg-gray-700 text-[#4A90E2] px-3 py-1 rounded-full">
                      {equation.type}
                    </span>
                    <span className="text-gray-500 dark:text-gray-400 text-xs">
                      {new Date(equation.timestamp).toLocaleString('ar-EG', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-3">
                    المعادلة:
                    <code className="block mt-1 bg-gray-100 dark:bg-gray-700 px-3 py-2 rounded-md text-[#4A90E2] font-mono text-base break-words">
                      {equation.equation}
                    </code>
                  </h3>
                  <p className="text-lg text-gray-700 dark:text-gray-300 mb-5">
                    النتيجة: <span className="font-medium">{equation.result}</span>
                  </p>
                </div>
                <button className="w-full py-2.5 px-4 rounded-lg text-white font-semibold bg-[#4A90E2] hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-[#4A90E2] focus:ring-opacity-50 transition-colors duration-300 text-base">
                  إعادة الحل
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center p-12 bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-100 dark:border-gray-700 max-w-xl mx-auto">
            <p className="text-gray-600 dark:text-gray-400 text-xl leading-relaxed">
              لم يتم حل أي معادلات بعد. ابدأ بحل بعض المسائل لتظهر في سجلّك هنا وتتمكن من الوصول إليها لاحقاً!
            </p>
            <button className="mt-8 py-3 px-8 rounded-lg text-white font-semibold bg-[#4A90E2] hover:bg-opacity-90 focus:outline-none focus:ring-2 focus:ring-[#4A90E2] focus:ring-opacity-50 transition-colors duration-300 text-lg">
              ابدأ حل معادلة جديدة
            </button>
          </div>
        )}
      </main>
    </div>
  );
}