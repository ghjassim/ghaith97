import React from 'react';

export default function HelpTutorialPage() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      {/* Header */}
      <header className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-semibold text-blue-600">Help & Tutorial</h1>
          <nav>
            <a href="/examples" className="text-gray-600 hover:text-blue-600 mr-4">
              Examples
            </a>
            <a href="/contact" className="text-gray-600 hover:text-blue-600">
              Contact
            </a>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-5xl mx-auto py-10 px-6">
        {/* Introduction */}
        <section className="mb-8">
          <h2 className="text-xl font-semibold text-blue-600 mb-2">
            Getting Started with the Equation Editor
          </h2>
          <p className="text-gray-600">
            Our equation editor lets you craft complex mathematical expressions
            using a simple, intuitive interface. Whether you're writing a proof,
            preparing a lecture note, or documenting research, the editor
            integrates seamlessly into your workflow.
          </p>
        </section>

        {/* Supported Equation Types */}
        <section className="mb-8">
          <h3 className="text-lg font-semibold text-blue-600 mb-2">
            Supported Equation Types
          </h3>
          <ul className="space-y-4 pl-6 list-disc">
            <li>
              <span className="font-medium">Linear Equations</span> – Simple
              algebraic expressions.
            </li>
            <li>
              <span className="font-medium">Quadratic Equations</span> – With
              discriminant and root notation.
            </li>
            <li>
              <span className="font-medium">Systems of Equations</span> – In
              matrix or simultaneous form.
            </li>
            <li>
              <span className="font-medium">Differential Equations</span> – First
              and second order, partial derivatives.
            </li>
            <li>
              <span className="font-medium">Integral Calculus</span> – Definite
              and indefinite integrals, limits.
            </li>
            <li>
              <span className="font-medium">Summation & Product Notation</span>
              – Compact summation & product representations.
            </li>
            <li>
              <span className="font-medium">Trigonometric & Hyperbolic</span>{' '}
              – Standard trig identities and hyperbolic functions.
            </li>
          </ul>
        </section>

        {/* Tips & Tricks */}
        <section className="mb-8">
          <h3 className="text-lg font-semibold text-blue-600 mb-2">
            Tips & Tricks
          </h3>
          <p className="text-gray-600">
            • Use the keyboard shortcuts to speed up typing. <br />
            • Hover over symbols for quick access to their LaTeX equivalents. <br />
            • Click the “Preview” button to render the equation in real time. <br />
            • Right‑click the rendered output to copy as PNG or LaTeX code.
          </p>
        </section>

        {/* Call to Action */}
        <section className="text-center mt-12">
          <button className="bg-blue-600 text-white py-2 px-6 rounded-md hover:bg-blue-700 transition">
            Explore the Editor
          </button>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-10">
        <div className="max-w-7xl mx-auto px-6 py-4 text-center text-gray-600">
          © 2026 MathPro. All rights reserved.
        </div>
      </footer>
    </div>
  );
}