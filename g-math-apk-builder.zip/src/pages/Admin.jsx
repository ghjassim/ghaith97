import React from 'react';

export default function AdminPanel() {
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-blue-500 text-white flex items-center justify-between px-4 py-3">
        <h1 className="text-2xl font-semibold">Admin Panel</h1>
      </header>
      <main className="p-4">
        {/* Main content goes here */}
      </main>
    </div>
  );
}