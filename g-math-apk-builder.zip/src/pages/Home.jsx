export default function Home() {
  const [equation, setEquation] = React.useState('');
  const [result, setResult] = React.useState('');

  const solve = () => {
    // Placeholder logic – replace with real solver
    setResult(`Result: ${equation} ≈ ...`);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center p-4">
      <header className="w-full max-w-3xl bg-[#4A90E2] text-white rounded-lg p-6 mb-8 shadow-md">
        <h1 className="text-3xl font-bold">Math Solver</h1>
      </header>

      <main className="w-full max-w-3xl bg-white rounded-lg p-8 shadow-sm">
        <form
          onSubmit={e => {
            e.preventDefault();
            solve();
          }}
          className="flex flex-col space-y-4"
        >
          <label className="block">
            <span className="text-gray-700 font-medium">Enter Equation</span>
            <input
              type="text"
              value={equation}
              onChange={e => setEquation(e.target.value)}
              className="mt-2 w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-[#4A90E2]"
              placeholder="e.g., 2x + 3 = 7"
              required
            />
          </label>

          <button
            type="submit"
            className="mt-2 bg-[#4A90E2] text-white font-semibold py-3 rounded-md hover:bg-[#357ABD] transition-colors"
          >
            Solve
          </button>
        </form>

        {result && (
          <section className="mt-8 border-t pt-4 space-y-2">
            <h2 className="text-xl font-semibold">Result</h2>
            <p className="bg-gray-50 p-3 rounded-md">{result}</p>
          </section>
        )}
      </main>

      <footer className="mt-8 text-sm text-gray-600">
        © 2026 MathSolver – Precision in every equation.
      </footer>
    </div>
  );
}