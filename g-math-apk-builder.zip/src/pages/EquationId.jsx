import React from 'react';

// For demonstration purposes, we're using mock data.
// In a real application, 'equation' data would typically be fetched dynamically
// based on the ':id' parameter from the URL, for example, using React Router's useParams.
const mockEquation = {
  id: 'eq-78901',
  title: 'Pythagorean Theorem',
  equationText: '$$a^2 + b^2 = c^2$$', // Using LaTeX-like syntax for display
  description: 'Relates the lengths of the legs and hypotenuse of a right-angled triangle.',
  savedDate: '2023-11-15T09:45:00Z',
  lastModified: '2023-11-15T10:10:30Z',
  tags: ['geometry', 'math', 'theorem', 'right-triangle'],
  solution: {
    type: 'geometric relationship',
    details: 'In a right-angled triangle, the square of the length of the hypotenuse (the side opposite the right angle) is equal to the sum of the squares of the lengths of the other two sides (legs).',
    example: 'If a=3 and b=4, then c = \\sqrt{3^2 + 4^2} = \\sqrt{9 + 16} = \\sqrt{25} = 5.',
  },
  complexity: 'Fundamental',
  author: 'Premium User',
  notes: 'Applicable only to Euclidean geometry and right-angled triangles. Essential for many engineering and physics calculations.'
};

export default function SavedEquationView() {
  const equation = mockEquation; // Replace with actual data fetching in a live app

  // Handle case where equation might not be found or loaded yet
  if (!equation) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="text-center text-gray-700">
          <h2 className="text-3xl font-bold mb-4">Equation Not Found</h2>
          <p className="text-lg">The equation you are looking for does not exist or could not be loaded.</p>
          <button className="mt-6 bg-blue-600 text-white hover:bg-blue-700 font-semibold py-2 px-5 rounded-lg transition duration-200 ease-in-out">
            Go Back
          </button>
        </div>
      </div>
    );
  }

  // Define the primary color for consistent use, approximating #4A90E2 with Tailwind's blue-600.
  // For exact color matching, #4A90E2 could be added to tailwind.config.js as a custom color, e.g., 'primary-blue'.
  const primaryColorClass = 'text-blue-600';
  const primaryBgColorClass = 'bg-blue-600';
  const primaryHoverBgColorClass = 'hover:bg-blue-700';

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto bg-white shadow-xl rounded-xl overflow-hidden">
        {/* Header Section */}
        <div className={`bg-gradient-to-r from-blue-600 to-blue-500 text-white p-6 sm:p-8`}>
          <h1 className="text-3xl sm:text-4xl font-extrabold mb-2 leading-tight">
            <span className="block">Saved Equation Details:</span>
            <span className="block mt-1 text-blue-100">{equation.title}</span>
          </h1>
          <p className="text-blue-200 text-lg sm:text-xl font-light mt-2">
            Equation ID: <span className="font-semibold">{equation.id}</span>
          </p>
        </div>

        {/* Main Content Grid */}
        <div className="p-6 sm:p-8 lg:p-10 grid grid-cols-1 md:grid-cols-3 gap-8">

          {/* Equation Display Card - Takes 2/3 width on medium screens and up */}
          <div className="md:col-span-2 bg-blue-50 border border-blue-200 rounded-lg p-6 shadow-sm flex flex-col">
            <h2 className={`text-2xl font-semibold ${primaryColorClass} mb-4 flex items-center`}>
              <svg className="w-7 h-7 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2zM9 9h6v6H9V9z"></path>
              </svg>
              The Equation
            </h2>
            <div className="flex-grow bg-white p-5 rounded-md border border-gray-300 shadow-inner overflow-x-auto">
              <pre className="font-mono text-xl sm:text-2xl text-gray-900 whitespace-pre-wrap leading-relaxed">
                <code>{equation.equationText}</code>
              </pre>
            </div>
            <p className="text-gray-700 mt-5 text-base leading-relaxed italic border-t border-gray-200 pt-4">
              <span className="font-medium">Description:</span> {equation.description}
            </p>
          </div>

          {/* Metadata Card - Takes 1/3 width on medium screens and up */}
          <div className="md:col-span-1 bg-gray-50 border border-gray-200 rounded-lg p-6 shadow-sm flex flex-col justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-gray-800 mb-4 flex items-center">
                <svg className="w-7 h-7 mr-3 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                Key Information
              </h2>
              <ul className="space-y-4 text-gray-700 text-base">
                <li>
                  <span className="font-medium text-gray-900">Saved On:</span> <br />{new Date(equation.savedDate).toLocaleString()}
                </li>
                <li>
                  <span className="font-medium text-gray-900">Last Modified:</span> <br />{new Date(equation.lastModified).toLocaleString()}
                </li>
                <li>
                  <span className="font-medium text-gray-900">Author:</span> {equation.author}
                </li>
                <li>
                  <span className="font-medium text-gray-900">Complexity:</span>
                  <span className="inline-flex items-center ml-2 px-3 py-1 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800 ring-1 ring-indigo-200">
                    {equation.complexity}
                  </span>
                </li>
              </ul>
            </div>
            <div className="mt-8 border-t border-gray-200 pt-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-3">Relevant Tags</h3>
              <div className="flex flex-wrap gap-2">
                {equation.tags.map(tag => (
                  <span key={tag} className="inline-flex items-center px-3.5 py-1.5 rounded-full text-sm font-medium bg-blue-100 text-blue-800 ring-1 ring-blue-200">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Solution and Additional Notes Section - Spans full width */}
          <div className="md:col-span-3 grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Solution Card */}
            <div className="bg-green-50 border border-green-200 rounded-lg p-6 shadow-sm">
              <h2 className="text-2xl font-semibold text-green-800 mb-4 flex items-center">
                <svg className="w-7 h-7 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                Solution / Principle
              </h2>
              <div className="bg-white border border-green-300 rounded-md p-5 text-green-800 shadow-inner">
                <p className="font-medium text-lg mb-2">{equation.solution.type}</p>
                <p className="text-base leading-relaxed">{equation.solution.details}</p>
                {equation.solution.example && (
                  <p className="mt-3 text-sm italic border-t border-green-200 pt-3">
                    <span className="font-semibold">Example:</span> <br />
                    <pre className="font-mono text-gray-900 whitespace-pre-wrap text-base mt-1">{equation.solution.example}</pre>
                  </p>
                )}
              </div>
            </div>

            {/* Additional Notes Card */}
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 shadow-sm">
              <h2 className="text-2xl font-semibold text-yellow-800 mb-4 flex items-center">
                <svg className="w-7 h-7 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                </svg>
                Additional Notes
              </h2>
              <div className="bg-white border border-yellow-300 rounded-md p-5 text-yellow-800 shadow-inner">
                <p className="text-base leading-relaxed">{equation.notes || 'No additional notes provided for this equation.'}</p>
              </div>
            </div>
          </div>


          {/* Action Buttons */}
          <div className="md:col-span-3 flex flex-col sm:flex-row justify-end gap-4 mt-6 border-t border-gray-200 pt-6">
            <button className="bg-gray-200 text-gray-800 hover:bg-gray-300 font-semibold py-3 px-7 rounded-lg transition duration-200 ease-in-out flex items-center justify-center">
              <svg className="w-5 h-5 inline-block mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path></svg>
              Edit Equation
            </button>
            <button className="bg-red-500 text-white hover:bg-red-600 font-semibold py-3 px-7 rounded-lg transition duration-200 ease-in-out flex items-center justify-center">
              <svg className="w-5 h-5 inline-block mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
              Delete Equation
            </button>
            <button className={`${primaryBgColorClass} text-white ${primaryHoverBgColorClass} font-semibold py-3 px-7 rounded-lg transition duration-200 ease-in-out flex items-center justify-center`}>
              <svg className="w-5 h-5 inline-block mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367